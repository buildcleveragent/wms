import subprocess,sys,os,json
from pathlib import Path
r=Path(__file__).resolve().parent
work=r/'lock-workspace'
results=[]
for name in ['requirements','prod','dev','test']:
 command=[sys.executable,'-m','piptools','compile','--generate-hashes','--reuse-hashes','requirements/'+name+'.in']
 with (r/('lock-'+name+'.log')).open('w') as stream:
  p=subprocess.run(command,cwd=work,env={**os.environ,'PIP_TOOLS_CACHE_DIR':str(r/'pip-tools-cache'),'PIP_CACHE_DIR':str(r/'pip-cache'),'CUSTOM_COMPILE_COMMAND':'python3.12 -m piptools compile --generate-hashes --reuse-hashes'},stdout=stream,stderr=subprocess.STDOUT,timeout=240)
 same=p.returncode==0 and (work/'requirements'/(name+'.txt')).read_bytes()==(Path('/wms/requirements')/(name+'.txt')).read_bytes()
 results.append({'lock':name,'exit_code':p.returncode,'identical':same})
 print(results[-1],flush=True)
(r/'lock-results.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(0 if all(x['identical'] for x in results) else 1)
