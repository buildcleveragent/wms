import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
names = subprocess.check_output(['docker', 'ps', '--filter',
    'label=com.wms.purpose=isolated-migration-test', '--format', '{{.Names}}'], text=True).splitlines()
rows = []
for name in names:
    assert name.startswith('wms-test-migration-')
    query = ('MYSQL_PWD="$MYSQL_ROOT_PASSWORD" exec mysql --connect-timeout=5 -uroot -N '
             '-D wms_db_test -e "SELECT DATABASE(); SELECT COUNT(*) FROM django_migrations; '
             'SELECT app,name FROM django_migrations ORDER BY applied DESC LIMIT 1;"')
    process = subprocess.run(['docker', 'exec', name, 'sh', '-c', query],
                             capture_output=True, text=True, timeout=12)
    if process.returncode:
        rows.append({'container': name, 'probe_exit_code': process.returncode})
        continue
    lines = process.stdout.splitlines()
    assert lines[0] == 'wms_db_test'
    rows.append({'container': name, 'database': lines[0], 'migrations': int(lines[1]),
                 'last_migration': lines[2] if len(lines) > 2 else None})
record = {'time': datetime.now(timezone.utc).isoformat(), 'instances': rows}
with (root / 'isolated-migration-progress.events.jsonl').open('a') as stream:
    stream.write(json.dumps(record) + '\n')
print(json.dumps(record))
