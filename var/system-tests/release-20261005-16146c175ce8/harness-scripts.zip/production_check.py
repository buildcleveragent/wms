import json
import os
import secrets
import subprocess
import sys
from pathlib import Path

import environ
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

root = Path(__file__).resolve().parent
environ.Env.read_env('/wms/.env.test.local', overwrite=False)
private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
private_path = root / 'synthetic-private.pem'
public_path = root / 'synthetic-public.pem'
private_path.write_bytes(private.private_bytes(serialization.Encoding.PEM,
    serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
private_path.chmod(0o600)
public_path.write_bytes(private.public_key().public_bytes(serialization.Encoding.PEM,
    serialization.PublicFormat.SubjectPublicKeyInfo))
environment = {
    **os.environ, 'APP_ENV': 'production', 'DEBUG': 'False',
    'DB_NAME': 'wms_db_test', 'DB_TEST_NAME': 'wms_db_test',
    'SECRET_KEY': secrets.token_hex(32), 'ALLOWED_HOSTS': 'wms.example.invalid,127.0.0.1',
    'CORS_ALLOWED_ORIGINS': 'https://wms.example.invalid',
    'CSRF_TRUSTED_ORIGINS': 'https://wms.example.invalid',
    'CORS_ALLOW_ALL_ORIGINS': 'False', 'WMS_ACCESS_SCOPE_LEGACY_FALLBACK': 'False',
    'WECHAT_MINI_APPID': 'wx-ci-deploy-check', 'WECHAT_PAY_MCH_ID': '1900000001',
    'WECHAT_PAY_MCH_SERIAL_NO': 'ci-merchant-serial',
    'WECHAT_PAY_PRIVATE_KEY': '', 'WECHAT_PAY_PRIVATE_KEY_PATH': str(private_path),
    'WECHAT_PAY_APIV3_KEY': secrets.token_hex(16),
    'WECHAT_PAY_NOTIFY_URL': 'https://wms.example.invalid/api/sale-mini/payments/wechat/notify/',
    'WECHAT_PAY_REFUND_NOTIFY_URL': 'https://wms.example.invalid/api/sale-mini/refunds/wechat/notify/',
    'WECHAT_PAY_PLATFORM_KEYS': json.dumps({'ci-platform-serial': str(public_path)}),
    'WECHAT_PAY_VERIFY_CALLBACK_SIGNATURE': 'True',
}
check = subprocess.run([sys.executable, 'manage.py', 'check', '--deploy'],
    cwd='/wms', env=environment, capture_output=True, text=True, timeout=60)
(root / 'production-system-check.log').write_text(check.stdout + check.stderr)
print('production_system_check_exit_code', check.returncode)
probe = '''import os,json,django
os.environ.setdefault('DJANGO_SETTINGS_MODULE','wmsmaster.settings')
django.setup()
from django.test import RequestFactory
from django.http import HttpResponse
from django.middleware.security import SecurityMiddleware
request=RequestFactory().get('/healthz/ready',HTTP_HOST='127.0.0.1:8000')
response=SecurityMiddleware(lambda request:HttpResponse('ready'))(request)
print(json.dumps({'status':response.status_code,'location':response.get('Location')}))
'''
result = subprocess.run([sys.executable, '-c', probe], cwd='/wms', env=environment,
    capture_output=True, text=True, timeout=60)
if result.returncode:
    print('production_probe_failed', result.returncode)
    sys.exit(2)
data = json.loads(result.stdout)
(root / 'production-probe.json').write_text(json.dumps(data, indent=2) + '\n')
print('production_http_health_probe', json.dumps(data))
private_path.unlink()
public_path.unlink()
sys.exit(0 if check.returncode == 0 and data['status'] == 200 else 1)
