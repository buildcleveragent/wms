import ast
import json
import os
import secrets
import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, '/app')
os.environ['SECRET_KEY'] = secrets.token_hex(32)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'wmsmaster.settings')
import django
django.setup()

# Reuse only the repository's pure synthetic-data function. The production
# image deliberately does not contain the pytest dependency of its test module.
tree = ast.parse(Path('/app/allapp/reports/test_pdf_acceptance.py').read_text())
sample = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'sample_note')
scope = {'Decimal': Decimal}
exec(compile(ast.Module(body=[sample], type_ignores=[]), '<sample_note>', 'exec'), scope)

from django.template.loader import render_to_string
from allapp.reports.views import _offline_url_fetcher
from weasyprint import HTML

html = render_to_string('reports/dispatch_note.html', {'note': scope['sample_note'](1)})
assert '中文长商品名称' in html
pdf = HTML(string=html, url_fetcher=_offline_url_fetcher).write_pdf(presentational_hints=False)
assert pdf.startswith(b'%PDF-') and len(pdf) > 10000
print(json.dumps({'status': 'PASS', 'pdf_bytes': len(pdf), 'rows': 1,
                  'scope': 'Real production-image template/native PDF renderer smoke, no DB or external network access'}))
