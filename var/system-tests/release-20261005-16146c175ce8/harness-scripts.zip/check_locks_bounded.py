import subprocess,sys,os,json,shutil
from pathlib import Path
r=Path(__file__).resolve().parent
work=r/'lock-workspace'
results=[]
for name in ['requirements','prod','dev','test']:
 shutil.copy2(Path('/wms/requirements')/(name+'.txt'),work/'requirements'/(name+'.txt'))
 command=[sys.executable,'-m','piptools','compile','--verbose','--generate-hashes','--reuse-hashes','--pip-args=--timeout=10 --retries=1','requirements/'+name+'.in']
 try:
  with (r/('lock-bounded-'+name+'.log')).open('w') as stream:
   p=subprocess.run(command,cwd=work,env={**os.environ,'PIP_TOOLS_CACHE_DIR':str(r/'pip-tools-cache'),'PIP_CACHE_DIR':str(r/'pip-cache'),'CUSTOM_COMPILE_COMMAND':'python3.12 -m piptools compile --generate-hashes --reuse-hashes'},stdout=stream,stderr=subprocess.STDOUT,timeout=120)
  same=p.returncode==0 and (work/'requirements'/(name+'.txt')).read_bytes()==(Path('/wms/requirements')/(name+'.txt')).read_bytes()
  row={'lock':name,'exit_code':p.returncode,'identical':same,'status':'PASS' if same else 'FAIL'}
 except subprocess.TimeoutExpired:
  row={'lock':name,'status':'BLOCKED_TIMEOUT','identical':False}
 results.append(row)
 (r/'lock-results-bounded.json').write_text(json.dumps(results,indent=2)+'\n')
 print(row,flush=True)
sys.exit(0 if all(x['identical'] for x in results) else 1)
