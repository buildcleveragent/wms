import http.client
import json
import os
import secrets
import subprocess
import time

environment = {**os.environ, 'APP_ENV': 'production', 'DEBUG': 'False',
               'SECRET_KEY': secrets.token_hex(32), 'ALLOWED_HOSTS': '127.0.0.1',
               'DB_NAME': 'wms_db_test', 'DB_TEST_NAME': 'wms_db_test'}
server = subprocess.Popen(['gunicorn', 'wmsmaster.wsgi:application', '--bind',
    '127.0.0.1:8000', '--workers', '1', '--timeout', '30'], env=environment,
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
result = None
try:
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline:
        if server.poll() is not None:
            break
        connection = http.client.HTTPConnection('127.0.0.1', 8000, timeout=3)
        try:
            connection.request('GET', '/healthz/ready')
            response = connection.getresponse()
            result = {'http_status': response.status, 'location': response.getheader('Location'),
                      'runtime': 'candidate Gunicorn process with production settings',
                      'network': 'none; loopback probe only',
                      'scope': 'Determine whether HTTP health checking reaches readiness handling or is redirected before DB access.'}
            break
        except (ConnectionError, TimeoutError, OSError):
            time.sleep(0.5)
        finally:
            connection.close()
finally:
    server.terminate()
    try:
        log = server.communicate(timeout=10)[0]
    except subprocess.TimeoutExpired:
        server.kill()
        log = server.communicate(timeout=5)[0]
    print(log)
print(json.dumps(result or {'status': 'STARTUP_FAILED'}))
raise SystemExit(0 if result and result['http_status'] == 200 else 1)
