import json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent
failed=[]
for spec in json.loads(Path(sys.argv[1]).read_text()):
 print('START '+Path(spec).stem,flush=True)
 result=subprocess.run([sys.executable,str(r/'run_job.py'),spec])
 if result.returncode:failed.append(Path(spec).stem)
print('FAILED_JOBS='+json.dumps(failed),flush=True)
sys.exit(bool(failed))
