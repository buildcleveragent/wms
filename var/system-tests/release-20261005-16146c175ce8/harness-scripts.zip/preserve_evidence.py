import json
import os
import shutil
import zipfile
from pathlib import Path

source = Path(__file__).resolve().parent
destination = Path('/wms/var/system-tests/release-20261005-16146c175ce8')
destination.mkdir(mode=0o700, parents=True, exist_ok=False)
excluded = {'frontend-source', 'build-products', 'buildx', 'lock-workspace',
            'pip-cache', 'pip-tools-cache', 'pip-audit-cache', 'npm-cache',
            'cache', 'trivy-cache', '__pycache__'}
count = total = 0
# Keep the temporary harness reviewable without introducing new loose Python
# files into the repository's lint discovery scope.
with zipfile.ZipFile(source / 'harness-scripts.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for helper in source.glob('*.py'):
        archive.write(helper, helper.name)
for entry in source.rglob('*'):
    relative = entry.relative_to(source)
    if relative.parts[0] in excluded:
        continue
    if entry.is_symlink() or any(part.startswith('.env') for part in relative.parts):
        continue
    if entry.suffix in {'.pem', '.key', '.p12', '.jks', '.keystore', '.pyc', '.py'}:
        continue
    if not entry.is_file():
        continue
    target = destination / relative
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    shutil.copy2(entry, target)
    target.chmod(0o600)
    count += 1
    total += target.stat().st_size
metadata = source / 'trivy-cache/db/metadata.json'
if metadata.exists():
    target = destination / 'trivy-cache/db/metadata.json'
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    shutil.copy2(metadata, target)
    target.chmod(0o600)
print(json.dumps({'evidence': str(destination), 'files': count, 'bytes': total,
                  'excluded': sorted(excluded), 'secret_config_files_copied': False}))
