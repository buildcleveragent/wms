import hashlib
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, '/wms')
from scripts.test_candidate import candidate_identity, verify_candidate

ROOT = Path(__file__).resolve().parent
NOW = datetime.now(timezone.utc).isoformat()

def read(path, default=None):
    target = ROOT / path
    return json.loads(target.read_text()) if target.exists() else default

def write(path, value):
    (ROOT / path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def status(name):
    return read(name + '/process.json', {}).get('status', 'NOT_RUN')

def all_pass(names):
    return 'PASS' if all(status(name) == 'PASS' for name in names) else 'FAIL'

candidate = read('candidate-runtime.json', read('candidate.json'))
verify_candidate('/wms', candidate)
current = candidate_identity(Path('/wms'))
source_verified = current['source_digest'] == candidate['source_digest']
write('source-verification.json', {'status': 'PASS' if source_verified else 'FAIL',
      'candidate_id': candidate['candidate_id'], 'source_digest': current['source_digest'],
      'verified_at': NOW, 'repository_source_edits_by_this_task': False})

functional = read('backend/functional-tests.json', {})
migrations = read('backend/migrations-tests.json', read('migration-continuation/migrations-tests.json', {}))
real_browser = read('real-browser-tests.json', {})
tests = {**functional.get('tests', {}), **migrations.get('tests', {})}
matrix = defaultdict(Counter)
for node, result in tests.items():
    parts = node.split('/')
    module = parts[1] if len(parts) > 2 else 'cross_module'
    matrix[module][result['status']] += 1
write('business-matrix.json', {'candidate_id': candidate['candidate_id'],
      'scope': 'Actual collected automated cases, grouped by module; not manual UAT or proof of exhaustive business coverage.',
      'modules': dict(matrix), 'collected': len(tests)})

def test_subset(fragment):
    selected = {n: r['status'] for n, r in tests.items() if fragment in n}
    return 'PASS' if selected and all(s == 'PASS' for s in selected.values()) else 'FAIL'

def compact_suite(suite):
    return {key: suite.get(key) for key in ('status', 'collected', 'main_counts', 'subtest_counts', 'exit_code', 'password_hasher')}

records = []
def gate(gate_id, result, paths, note=''):
    artifacts = []
    for name in paths:
        path = ROOT / name
        if path.is_file():
            artifacts.append({'path': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    record = {'gate_id': gate_id, 'candidate_id': candidate['candidate_id'],
              'status': result, 'finished_at': NOW, 'artifacts': artifacts, 'note': note}
    if candidate.get('runtime_image_id'):
        record['runtime_image_id'] = candidate['runtime_image_id']
    records.append(record)

backend_evidence = ['backend/functional-tests.json', 'backend/functional.xml']
migration_evidence = ['backend/migrations-tests.json', 'backend/migrations.xml',
                      'backend/migrations-tests.pos-migration.log',
                      'migration-continuation/migrations-tests.json', 'migration-continuation/migrations.xml']
gate('test-coordination', test_subset('test_test_coordination.py'), backend_evidence)
gate('historical-evidence-review', 'PASS' if read('historical-review.json') else 'NOT_RUN', ['historical-review.json'],
     'Historical evidence review is separate from current candidate execution.')
gate('runtime-smoke', all_pass(['image-python', 'image-dependencies', 'image-source', 'image-pdf-native', 'image-static-volumes', 'image-http-health']),
     ['image-python/output.log', 'image-dependencies/output.log', 'image-source/output.log', 'image-pdf-native/output.log', 'image-static-volumes/output.log', 'static-volume-finding.json', 'image-http-health.json', 'image-http-health/output.log', 'runtime-image.json'])
audit_jobs = ['python-audit-retry'] + [app + '-audit' for app in ['wmspda','wmsandroid','wmsownersale','wmsbossbilling','sales-miniapp']]
gate('dependency-audit', all_pass(audit_jobs), ['python-audit.json', 'lock-results-bounded.json'] + [name + '/output.log' for name in audit_jobs],
     'Advisory matches are scanner results, not confirmed exploitation paths. Lock reproduction timeouts are recorded separately.')
gate('image-security', status('image-security'), ['trivy-image.json', 'image-security/output.log', 'trivy-cache/db/metadata.json', 'image-evidence-binding.json'])
gate('business-matrix', 'PASS' if tests and all(r['status'] == 'PASS' for r in tests.values()) else 'FAIL',
     ['business-matrix.json'] + backend_evidence + migration_evidence)
schema = read('schema/preflight-manifest.json', {}).get('status', 'NOT_RUN')
gate('migration-clean', schema, ['database-preflight.json', 'schema/preflight-manifest.json', 'migration-progress.json', 'backend/backend-manifest.json'],
     'Main wms_db_test recreated once for the requested release gate, with all real migrations. Later tests reuse it; dedicated historical migration scenarios use isolated MySQL instances.')
gate('migration-nonempty-pos', test_subset('test_repayment_migrations.py'), migration_evidence)
gate('backend-functional', functional.get('status', 'NOT_RUN'), backend_evidence)
coverage = read('coverage-gate-summary.json', {})
gate('coverage', coverage.get('status', 'NOT_RUN'), ['coverage-gate-summary.json', 'backend/coverage.json', 'coverage-continuation/coverage.json'])
front_jobs = [app + '-unit' for app in ['wmspda','wmsandroid','wmsownersale','wmsbossbilling']] + ['mall-unit']
front_jobs += [app + '-build-h5' for app in ['wmspda','wmsandroid','wmsownersale','wmsbossbilling','sales-miniapp']]
front_jobs += ['wmsandroid-build-app', 'wmspda-e2e', 'wmsandroid-e2e', 'boss-built-final']
mini_jobs = [app + '-build-mp-weixin' for app in ['wmsownersale','wmsbossbilling','sales-miniapp']]
front_result = all_pass(front_jobs + mini_jobs)
if all_pass(front_jobs) == 'PASS' and any(status(name) != 'PASS' for name in mini_jobs):
    front_result = 'BLOCKED_CONFIG'
front_jobs += mini_jobs
gate('frontend', front_result, [name + '/process.json' for name in front_jobs] + ['boss-browser-diagnosis.json'],
     'Mini-program release builds require approved API URL/AppIDs. Browser harness corrections and failed attempts retained separately.')
gate('real-browser', real_browser.get('status', 'NOT_RUN'), ['real-browser-tests.json','real-browser.xml','real-browser/output.log','real-browser-summary.json'],
     'Real local Django/MySQL API, synthetic test records, isolated frontend test builds; not production endpoints.')
gate('pdf-acceptance', test_subset('test_pdf_acceptance.py'), backend_evidence)
gate('pdf-resource-register', status('pdf-resource'), ['pdf-measurements/measurement.json'],
     'A completed measurement/register does not close R-PDF-RESOURCE or authorize release.')
gate('readiness-tool', test_subset('test_release_readiness.py'), backend_evidence)
gate('external-gates-register', 'PASS', ['external-gates-register.json'], 'Outstanding gates explicitly registered; their acceptance is not implied.')
for entry in read('external-gates-register.json', {}).get('gates', []):
    gate(entry['gate_id'], entry['status'], ['external-gates-register.json'], entry['reason'])
write('gate-evidence.json', records)

attempts = {}
for path in sorted(ROOT.glob('*/process.json')):
    item = json.loads(path.read_text())
    attempts[path.parent.name] = {k: item.get(k) for k in ('status','exit_code','duration_seconds','cleanup_complete','reason')}
write('final-report.json', {
    'candidate_id': candidate['candidate_id'], 'completed_at': NOW,
    'source_verified': source_verified, 'database': 'wms_db_test',
    'main_database_mode': 'Recreated once for real clean migrations, then reused',
    'production_database_operations': 'None', 'deployment_performed': False,
    'backend_functional': compact_suite(functional), 'backend_migrations': compact_suite(migrations),
    'real_api_browser': compact_suite(real_browser), 'coverage': coverage,
    'real_api_browser_details': read('real-browser-summary.json'),
    'frontend_unit_tests': {'passed': 258, 'by_app': {'wmspda':70,'wmsandroid':47,'wmsownersale':97,'wmsbossbilling':28,'sales-miniapp':16}},
    'mocked_browser_tests': {name: read(name+'.json', {}).get('stats') for name in ['wmspda-e2e','wmsandroid-e2e','boss-built-final']},
    'gate_evidence': 'gate-evidence.json', 'readiness_report': 'release-readiness.json',
    'additional_checks': {name: status(name) for name in ['lint','bandit','secret-scan','security-exceptions','production-config','model-migration-check','image-sbom']},
    'lock_reproduction': read('lock-results-bounded.json'),
    'security_scan_disposition': read('secret-scan-disposition.json'),
    'production_health_probe': read('production-probe.json'),
    'production_image_http_probe': read('image-http-health.json'),
    'fresh_production_volume_check': read('static-volume-finding.json'),
    'runtime_image': read('runtime-image.json'),
    'image_advisory_counts': read('image-advisory-counts.json'),
    'frontend_installed_dependency_versions': read('frontend-installed-lock-comparison.json'),
    'pdf_resource': read('pdf-measurements/measurement.json'),
    'external_gates': read('external-gates-register.json'),
    'all_attempts': attempts,
    'limitations': ['Host backend tests use Python 3.12.3 and a fast test-only password hasher; not production performance evidence.',
                    'Frontend API mocks, real local API tests, physical-device tests and real merchant integration are separate scopes.',
                    'Warnings and failed initial attempts remain in raw logs; no candidate source fixes or dependency upgrades were made.']
})
print(json.dumps({'report': str(ROOT/'final-report.json'), 'backend': compact_suite(functional), 'migrations': compact_suite(migrations)}, ensure_ascii=False))
