from pathlib import Path
def pytest_collection_modifyitems(items):
    for item in items:
        if getattr(item.module, '__file__', '').endswith('/scripts/test_real_browser_acceptance.py'):
            item.module.ROOT = Path('/tmp/wms-release-20261005-aohudxd1/frontend-source')
