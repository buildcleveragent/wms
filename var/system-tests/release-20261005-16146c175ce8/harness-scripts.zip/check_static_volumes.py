import subprocess
import sys
import uuid

suffix = uuid.uuid4().hex[:12]
names = ['wms-release-static-' + suffix, 'wms-release-media-' + suffix]
container = 'wms-release-static-probe-' + suffix
created = []
try:
    for name in names:
        subprocess.run(['docker', 'volume', 'create', '--label',
                        'com.wms.purpose=release-gate-temporary', name],
                       check=True, capture_output=True, timeout=20)
        created.append(name)
    code = """import os,secrets
os.environ['SECRET_KEY']=secrets.token_hex(32)
os.environ.setdefault('DJANGO_SETTINGS_MODULE','wmsmaster.settings')
print('effective_uid', os.getuid(), flush=True)
for path in ('/app/staticfiles','/app/media'):
    state=os.stat(path)
    print('volume', path, 'owner', state.st_uid, 'mode', oct(state.st_mode & 0o777), 'writable', os.access(path,os.W_OK), flush=True)
from django.core.management import execute_from_command_line
execute_from_command_line(['manage.py','collectstatic','--noinput'])
"""
    result = subprocess.run(['docker', 'run', '--rm', '--network', 'none', '--name', container,
        '--mount', 'type=volume,source=' + names[0] + ',target=/app/staticfiles',
        '--mount', 'type=volume,source=' + names[1] + ',target=/app/media',
        '-e', 'APP_ENV=test', '-e', 'DB_NAME=wms_db_test', '-e', 'DB_TEST_NAME=wms_db_test',
        'wms-release:20261005-16146c175ce8', 'python', '-c', code], timeout=90)
    sys.exit(result.returncode)
finally:
    # Only this helper's freshly named resources are eligible for cleanup.
    subprocess.run(['docker', 'rm', '-f', container], capture_output=True, timeout=20)
    for name in created:
        subprocess.run(['docker', 'volume', 'rm', name], check=True, capture_output=True, timeout=20)
    print('temporary volumes cleaned', len(created), flush=True)
