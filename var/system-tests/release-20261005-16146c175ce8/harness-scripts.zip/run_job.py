import json
import os
import sys
from pathlib import Path

sys.path.insert(0, '/wms')
from scripts.test_process import run_managed

root = Path(__file__).resolve().parent
spec = json.loads(Path(sys.argv[1]).read_text())
directory = root / spec['name']
directory.mkdir(parents=True, exist_ok=True)
with (directory / 'output.log').open('x') as stream:
    result = run_managed(
        spec['command'], cwd=Path(spec.get('cwd', '/wms')),
        env={**os.environ, **spec.get('env', {})}, stdout=stream,
        record_path=directory / 'process.json',
        timeout=spec.get('timeout', 600),
        docker_cleanup=spec.get('docker_cleanup', False),
    )
print(json.dumps({'name': spec['name'], **{key: result.get(key) for key in
    ('status', 'exit_code', 'duration_seconds', 'cleanup_complete', 'reason')}}), flush=True)
print('\n'.join((directory / 'output.log').read_text(errors='replace').splitlines()[-18:]), flush=True)
raise SystemExit(0 if result['status'] == 'PASS' else 1)
