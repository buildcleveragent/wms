import datetime
import json
import tempfile
from decimal import Decimal
from io import StringIO
from pathlib import Path

from cryptography.fernet import Fernet
from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase, override_settings
from rest_framework.test import APIClient

from allapp.baseinfo.models import Owner
from allapp.billing.enums import AccrualStatus, CalcMethod, ChargeType
from allapp.billing.models import (
    Bill,
    BillingAccrual,
    BillingPeriod,
    BillingRule,
    BillLine,
)
from allapp.core.admin import SystemSettingAdminForm
from allapp.core.choices import InvTxType
from allapp.core.models import (
    SECRET_VALUE_PREFIX,
    DocSequence,
    PrintConfig,
    SecretSettingError,
    SystemSetting,
)
from allapp.inventory.models import (
    InventoryDetail,
    InventorySummary,
    InventoryTransaction,
)
from allapp.locations.models import Location, Subwarehouse, Warehouse
from allapp.products.models import Product, ProductUom

TEST_SYSTEM_SETTING_KEY = Fernet.generate_key().decode("ascii")


@override_settings(SYSTEM_SETTING_ENCRYPTION_KEY=TEST_SYSTEM_SETTING_KEY)
class SystemSettingSecretTests(TestCase):
    def _setting(self):
        return SystemSetting.objects.create(
            namespace="integration",
            key="secret-test",
            name="Secret test",
            value_type=SystemSetting.ValueType.STRING,
            is_secret=True,
            client_visible=False,
        )

    def test_secret_is_encrypted_and_only_explicit_secret_reader_decrypts(self):
        setting = self._setting()
        setting.set_secret_value("provider-secret-value")
        setting.save(update_fields=["value", "updated_at"])

        setting.refresh_from_db()
        self.assertTrue(setting.value.startswith(SECRET_VALUE_PREFIX))
        self.assertNotIn("provider-secret-value", setting.value)
        self.assertEqual(setting.effective_value(), "")
        self.assertIsNone(SystemSetting.get_value(setting.namespace, setting.key, None))
        self.assertEqual(
            SystemSetting.get_secret_value(setting.namespace, setting.key),
            "provider-secret-value",
        )

    def test_secret_key_fallback_and_wrong_key_fail_safely(self):
        with override_settings(
            SYSTEM_SETTING_ENCRYPTION_KEY="",
            SECRET_KEY="stable-django-secret",
        ):
            setting = self._setting()
            setting.set_secret_value("provider-secret-value")
            setting.save(update_fields=["value", "updated_at"])
            self.assertEqual(setting.secret_value(), "provider-secret-value")

        with override_settings(
            SYSTEM_SETTING_ENCRYPTION_KEY="",
            SECRET_KEY="different-django-secret",
        ):
            with self.assertRaisesRegex(SecretSettingError, "无法解密"):
                setting.secret_value()
        with override_settings(SYSTEM_SETTING_ENCRYPTION_KEY=Fernet.generate_key().decode()):
            with self.assertRaisesRegex(SecretSettingError, "无法解密"):
                setting.secret_value()

    def test_admin_form_masks_and_preserves_or_replaces_existing_secret(self):
        setting = self._setting()
        setting.set_secret_value("old-secret")
        setting.save(update_fields=["value", "updated_at"])
        original_ciphertext = setting.value
        base_data = {
            "namespace": setting.namespace,
            "key": setting.key,
            "name": setting.name,
            "value_type": setting.value_type,
            "default_value": "",
            "description": "",
            "client_visible": False,
            "is_secret": True,
            "is_active": True,
            "sort_order": 0,
            "options": "{}",
        }

        preserved = SystemSettingAdminForm(
            data={**base_data, "value": ""},
            instance=setting,
        )
        self.assertTrue(preserved.is_valid(), preserved.errors)
        preserved.save()
        setting.refresh_from_db()
        self.assertEqual(setting.value, original_ciphertext)

        replaced = SystemSettingAdminForm(
            data={**base_data, "value": "new-secret"},
            instance=setting,
        )
        self.assertTrue(replaced.is_valid(), replaced.errors)
        replaced.save()
        setting.refresh_from_db()
        self.assertNotEqual(setting.value, original_ciphertext)
        self.assertEqual(setting.secret_value(), "new-secret")

    def test_admin_form_uses_secret_key_fallback_without_dedicated_key(self):
        setting = self._setting()
        base_data = {
            "namespace": setting.namespace,
            "key": setting.key,
            "name": setting.name,
            "value_type": setting.value_type,
            "value": "new-secret",
            "default_value": "",
            "description": "",
            "client_visible": False,
            "is_secret": True,
            "is_active": True,
            "sort_order": 0,
            "options": "{}",
        }

        with override_settings(
            SYSTEM_SETTING_ENCRYPTION_KEY="",
            SECRET_KEY="admin-form-django-secret",
        ):
            form = SystemSettingAdminForm(data=base_data, instance=setting)
            self.assertTrue(form.is_valid(), form.errors)
            saved = form.save()
            self.assertEqual(saved.secret_value(), "new-secret")

    def test_secret_cannot_be_client_visible(self):
        setting = self._setting()
        setting.client_visible = True
        with self.assertRaisesRegex(Exception, "禁止向前端公开"):
            setting.full_clean()


class CoreWarehouseScopeTests(TestCase):
    def test_doc_sequence_without_warehouse_stays_null(self):
        owner = Owner.objects.create(name="Owner Core", code="OWN-CORE")
        biz_date = datetime.date(2026, 3, 29)

        next_no = DocSequence.next_number(
            doc_type="CORE",
            warehouse=None,
            owner=owner,
            biz_date=biz_date,
        )

        seq = DocSequence.objects.get(
            doc_type="CORE",
            biz_date=biz_date,
            owner=owner,
            warehouse__isnull=True,
        )
        self.assertEqual(next_no, 1)
        self.assertIsNone(seq.warehouse_id)


@override_settings(
    PASSWORD_HASHERS=["django.contrib.auth.hashers.MD5PasswordHasher"],
    SYSTEM_SETTING_ENCRYPTION_KEY=TEST_SYSTEM_SETTING_KEY,
)
class PrintConfigApiTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="print-config-user",
            password="pass",
        )
        self.client = APIClient()
        self.client.force_authenticate(self.user)
        # Data migrations seed these rows in a fresh deployment, but test
        # database flushes (and --reuse-db across suites) intentionally do not
        # replay RunPython operations.  Keep this API test self-contained.
        PrintConfig.objects.update_or_create(
            code="pos_dot_241_93",
            defaults={
                "name": "POS 默认针式三等分",
                "module": PrintConfig.Module.POS_SALE,
                "is_default": True,
                "is_active": True,
                "sort_order": 10,
            },
        )
        PrintConfig.objects.update_or_create(
            code="outbound_dot_241_93",
            defaults={
                "name": "出库单默认针式三等分",
                "module": PrintConfig.Module.OUTBOUND,
                "print_method": PrintConfig.PrintMethod.BACKEND_HTML,
                "printer_type": PrintConfig.PrinterType.DOT_MATRIX,
                "paper_mode": "dot_241_93",
                "paper_width": "9.5in",
                "paper_height": "3.6667in",
                "page_size_css": "9.5in 3.6667in",
                "body_font_size": "13px",
                "is_default": True,
                "is_active": True,
                "sort_order": 10,
            },
        )

    def test_configuration_endpoints_require_authentication(self):
        anonymous = APIClient()

        for path in (
            "/api/core/settings/",
            "/api/core/print-configs/",
            "/api/core/print-configs/default/",
        ):
            with self.subTest(path=path):
                response = anonymous.get(path)
                self.assertEqual(response.status_code, 401)

    def test_system_settings_only_expose_active_client_visible_values(self):
        secret = SystemSetting.objects.create(
            namespace="integration",
            key="api_secret",
            name="API secret",
            is_secret=True,
            client_visible=False,
            is_active=True,
        )
        secret.set_secret_value("must-not-leak")
        secret.save(update_fields=["value", "updated_at"])
        # Even a direct database update must not make encrypted settings public.
        SystemSetting.objects.filter(pk=secret.pk).update(client_visible=True)
        SystemSetting.objects.create(
            namespace="integration",
            key="retired_flag",
            name="Retired flag",
            value="true",
            value_type=SystemSetting.ValueType.BOOLEAN,
            client_visible=True,
            is_active=False,
        )
        SystemSetting.objects.create(
            namespace="integration",
            key="feature_enabled",
            name="Feature enabled",
            value="true",
            value_type=SystemSetting.ValueType.BOOLEAN,
            client_visible=True,
            is_active=True,
        )

        response = self.client.get("/api/core/settings/")

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["flat"]["integration.feature_enabled"])
        self.assertNotIn("integration.api_secret", response.data["flat"])
        self.assertNotIn("integration.retired_flag", response.data["flat"])

    def test_system_settings_include_pos_sale_print_config(self):
        response = self.client.get("/api/core/settings/")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.data["flat"]["pos.sale_print_method"],
            SystemSetting.POS_SALE_PRINT_FRONTEND,
        )
        self.assertEqual(
            response.data["flat"]["pos.sale_print_config"],
            SystemSetting.POS_DEFAULT_SALE_PRINT_CONFIG,
        )

    def test_default_print_config_uses_system_setting_code(self):
        PrintConfig.objects.create(
            code="pos_test_print_config",
            name="测试打印配置",
            module=PrintConfig.Module.POS_SALE,
            paper_mode="dot_241_93",
            paper_width="241mm",
            paper_height="93mm",
            page_size_css="241mm 93mm",
            sheet_width="188mm",
            is_active=True,
            is_default=False,
            sort_order=1,
        )
        SystemSetting.objects.update_or_create(
            namespace=SystemSetting.POS_NAMESPACE,
            key=SystemSetting.POS_SALE_PRINT_CONFIG_KEY,
            defaults={
                "name": "POS销售单打印配置",
                "value_type": SystemSetting.ValueType.STRING,
                "value": "pos_test_print_config",
                "default_value": SystemSetting.POS_DEFAULT_SALE_PRINT_CONFIG,
                "client_visible": True,
                "is_active": True,
                "sort_order": 11,
            },
        )

        response = self.client.get("/api/core/print-configs/default/?module=pos_sale")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["code"], "pos_test_print_config")
        self.assertEqual(response.data["page_size"], "241mm 93mm")
        self.assertEqual(response.data["sheet_width"], "188mm")

    def test_print_config_list_returns_results_and_default(self):
        response = self.client.get("/api/core/print-configs/?module=pos_sale")

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data["results"])
        self.assertEqual(response.data["default"]["code"], "pos_dot_241_93")
        self.assertEqual(
            response.data["default"]["font_family"],
            "Microsoft YaHei, Arial, sans-serif",
        )

    def test_outbound_default_print_config_and_fallback_order(self):
        default_config = PrintConfig.get_default(PrintConfig.Module.OUTBOUND)

        self.assertEqual(default_config.code, "outbound_dot_241_93")
        self.assertTrue(default_config.is_active)
        self.assertTrue(default_config.is_default)
        self.assertEqual(default_config.page_size_css, "9.5in 3.6667in")
        self.assertEqual(default_config.body_font_size, "13px")
        response = self.client.get("/api/core/print-configs/default/?module=outbound")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["code"], "outbound_dot_241_93")
        self.assertEqual(
            response.data["font_family"],
            "Microsoft YaHei, Arial, sans-serif",
        )

        default_config.is_default = False
        default_config.sort_order = 20
        default_config.save(update_fields=["is_default", "sort_order", "updated_at"])
        fallback = PrintConfig.objects.create(
            code="outbound_test_fallback",
            name="出库测试回退配置",
            module=PrintConfig.Module.OUTBOUND,
            is_default=False,
            is_active=True,
            sort_order=1,
        )

        self.assertEqual(
            PrintConfig.get_default(PrintConfig.Module.OUTBOUND),
            fallback,
        )


class DataAccuracyCommandTests(TestCase):
    def setUp(self):
        self.owner = Owner.objects.create(name="Accuracy Owner", code="ACC-OWN")
        self.warehouse = Warehouse.objects.create(code="ACC-WH", name="Accuracy Warehouse")
        self.subwarehouse = Subwarehouse.objects.create(
            warehouse=self.warehouse,
            code="ACC01",
            name="Accuracy Subwarehouse",
        )
        self.location = Location.objects.create(
            warehouse=self.warehouse,
            code="ACC01-01-01-01",
            name="Accuracy Location",
        )
        self.base_uom = ProductUom.objects.create(code="PCS-ACC", name="Piece", decimal_places=0)
        self.product = Product.objects.create(
            owner=self.owner,
            code="ACC-SKU",
            name="Accuracy SKU",
            sku="ACC-SKU",
            base_uom=self.base_uom,
            volume=Decimal("0.250000"),
            price=Decimal("10.00"),
            batch_control=False,
            expiry_control=False,
        )
        self.period = BillingPeriod.objects.create(
            owner=self.owner,
            warehouse=self.warehouse,
            label="2026-04",
            start_date=datetime.date(2026, 4, 1),
            end_date=datetime.date(2026, 4, 30),
            currency="CNY",
        )
        self.rule = BillingRule.objects.create(
            owner=self.owner,
            warehouse=self.warehouse,
            charge_type=ChargeType.STORAGE,
            calc_method=CalcMethod.PER_CBM_DAY,
            unit_price=Decimal("2.0000"),
            currency="CNY",
        )

    def create_posted_transaction(
        self,
        *,
        product=None,
        qty_delta="1.0000",
        batch_no="",
        production_date=None,
        expiry_date=None,
        serial_no="",
        location=None,
    ):
        next_src_id = InventoryTransaction.objects.count() + 1
        qty_delta = Decimal(qty_delta)
        return InventoryTransaction.objects.create(
            tx_type=InvTxType.RECEIVE if qty_delta > 0 else InvTxType.ISSUE,
            owner=self.owner,
            product=product or self.product,
            warehouse=self.warehouse,
            subwarehouse=self.subwarehouse,
            location=location or self.location,
            qty_delta=qty_delta,
            batch_no=batch_no,
            production_date=production_date,
            expiry_date=expiry_date,
            serial_no=serial_no,
            src_model="core.data_accuracy.tests",
            src_id=next_src_id,
            src_line_id=next_src_id,
            src_no=f"ACC-TX-{next_src_id}",
            posted_at=datetime.datetime(2026, 4, 2, 10, 0),
        )

    def create_consistent_inventory(self):
        InventoryDetail.objects.create(
            owner=self.owner,
            product=self.product,
            warehouse=self.warehouse,
            location=self.location,
            onhand_qty=Decimal("5.0000"),
            allocated_qty=Decimal("1.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )
        self.create_posted_transaction(qty_delta="5.0000")
        InventorySummary.objects.create(
            owner=self.owner,
            product=self.product,
            onhand_qty=Decimal("5.0000"),
            allocated_qty=Decimal("1.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )

    def create_consistent_billing(self):
        accrual = BillingAccrual.objects.create(
            owner=self.owner,
            warehouse=self.warehouse,
            period=self.period,
            charge_type=ChargeType.STORAGE,
            rule=self.rule,
            service_date=datetime.date(2026, 4, 2),
            currency="CNY",
            quantity=Decimal("1.2500"),
            unit_price=Decimal("2.0000"),
            amount=Decimal("2.50"),
            tax_amount=Decimal("0.00"),
            status=AccrualStatus.INVOICED,
            acc_fingerprint="acc-accuracy-1",
        )
        bill = Bill.objects.create(
            owner=self.owner,
            warehouse=self.warehouse,
            period=self.period,
            invoice_no="INV-ACC-001",
            issue_date=datetime.date(2026, 4, 3),
            due_date=datetime.date(2026, 4, 10),
            currency="CNY",
            subtotal=Decimal("2.50"),
            tax_total=Decimal("0.00"),
            total=Decimal("2.50"),
        )
        BillLine.objects.create(
            bill=bill,
            accrual=accrual,
            charge_type=ChargeType.STORAGE,
            service_date=accrual.service_date,
            quantity=accrual.quantity,
            unit_price=accrual.unit_price,
            amount=accrual.amount,
            tax_amount=accrual.tax_amount,
            description="accuracy line",
        )
        return bill

    def test_reconcile_data_accuracy_command_reports_pass_for_consistent_data(self):
        self.create_consistent_inventory()
        self.create_consistent_billing()

        out = StringIO()
        call_command(
            "reconcile_data_accuracy",
            "--owner",
            str(self.owner.id),
            "--json",
            stdout=out,
        )

        payload = json.loads(out.getvalue())
        self.assertTrue(payload["ok"])
        self.assertEqual(payload["issue_count"], 0)

    def test_reconcile_data_accuracy_command_detects_inventory_summary_mismatch(self):
        InventoryDetail.objects.create(
            owner=self.owner,
            product=self.product,
            warehouse=self.warehouse,
            location=self.location,
            onhand_qty=Decimal("5.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )
        InventorySummary.objects.create(
            owner=self.owner,
            product=self.product,
            onhand_qty=Decimal("4.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )

        out = StringIO()
        call_command(
            "reconcile_data_accuracy",
            "--owner",
            str(self.owner.id),
            "--inventory-only",
            "--json",
            stdout=out,
        )
        payload = json.loads(out.getvalue())
        self.assertFalse(payload["ok"])
        self.assertGreater(payload["issue_count"], 0)
        summary_check = next(
            check
            for check in payload["inventory"]["checks"]
            if check["name"] == "inventory_summary_vs_detail"
        )
        self.assertFalse(summary_check["ok"])

        with self.assertRaises(CommandError):
            call_command(
                "reconcile_data_accuracy",
                "--owner",
                str(self.owner.id),
                "--inventory-only",
                "--fail-on-issues",
            )

    def test_reconcile_data_accuracy_command_detects_bill_header_mismatch(self):
        self.create_consistent_billing()
        Bill.objects.filter(invoice_no="INV-ACC-001").update(total=Decimal("9.99"))

        out = StringIO()
        call_command(
            "reconcile_data_accuracy",
            "--owner",
            str(self.owner.id),
            "--billing-only",
            "--period",
            str(self.period.id),
            "--json",
            stdout=out,
        )

        payload = json.loads(out.getvalue())
        self.assertFalse(payload["ok"])
        check_names = [check["name"] for check in payload["billing"]["checks"] if not check["ok"]]
        self.assertIn("bill_header_totals", check_names)

    def test_reconcile_data_accuracy_command_detects_inventory_transaction_replay_mismatch(
        self,
    ):
        InventoryDetail.objects.create(
            owner=self.owner,
            product=self.product,
            warehouse=self.warehouse,
            location=self.location,
            onhand_qty=Decimal("5.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )
        InventorySummary.objects.create(
            owner=self.owner,
            product=self.product,
            onhand_qty=Decimal("5.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )
        self.create_posted_transaction(qty_delta="4.0000")

        out = StringIO()
        call_command(
            "reconcile_data_accuracy",
            "--owner",
            str(self.owner.id),
            "--inventory-only",
            "--json",
            stdout=out,
        )

        payload = json.loads(out.getvalue())
        checks = {check["name"]: check for check in payload["inventory"]["checks"]}
        self.assertFalse(payload["ok"])
        self.assertIn("inventory_transaction_replay_onhand", checks)
        self.assertFalse(checks["inventory_transaction_replay_onhand"]["ok"])
        self.assertEqual(
            checks["inventory_transaction_replay_onhand"]["samples"][0]["issue"],
            "detail_onhand_replay_mismatch",
        )
        self.assertEqual(
            checks["inventory_transaction_replay_onhand"]["samples"][0]["replayed_onhand_qty"],
            "4.0000",
        )

    def test_reconcile_data_accuracy_command_detects_batch_serial_expiry_issues(self):
        batch_product = Product.objects.create(
            owner=self.owner,
            code="ACC-BATCH",
            name="Accuracy Batch SKU",
            sku="ACC-BATCH",
            base_uom=self.base_uom,
            volume=Decimal("0.100000"),
            price=Decimal("12.00"),
            batch_control=True,
            expiry_control=False,
        )
        expiry_product = Product.objects.create(
            owner=self.owner,
            code="ACC-EXP",
            name="Accuracy Expiry SKU",
            sku="ACC-EXP",
            base_uom=self.base_uom,
            volume=Decimal("0.200000"),
            price=Decimal("15.00"),
            batch_control=False,
            expiry_control=True,
            expiry_basis="MFG",
            shelf_life_days=30,
            expiry_warning_days=5,
        )
        serial_product = Product.objects.create(
            owner=self.owner,
            code="ACC-SERIAL",
            name="Accuracy Serial SKU",
            sku="ACC-SERIAL",
            base_uom=self.base_uom,
            volume=Decimal("0.050000"),
            price=Decimal("20.00"),
            serial_control=True,
            batch_control=False,
            expiry_control=False,
        )

        batch_detail = InventoryDetail.objects.create(
            owner=self.owner,
            product=batch_product,
            warehouse=self.warehouse,
            location=self.location,
            batch_no="LOT-001",
            onhand_qty=Decimal("1.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )
        batch_tx = self.create_posted_transaction(
            product=batch_product,
            qty_delta="1.0000",
            batch_no="LOT-001",
        )
        InventoryDetail.objects.filter(pk=batch_detail.pk).update(batch_no="")
        InventoryTransaction.objects.filter(pk=batch_tx.pk).update(batch_no="")

        expiry_detail = InventoryDetail.objects.create(
            owner=self.owner,
            product=expiry_product,
            warehouse=self.warehouse,
            location=self.location,
            production_date=datetime.date(2026, 4, 1),
            expiry_date=datetime.date(2026, 5, 1),
            onhand_qty=Decimal("2.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )
        expiry_tx = self.create_posted_transaction(
            product=expiry_product,
            qty_delta="2.0000",
            production_date=datetime.date(2026, 4, 1),
            expiry_date=datetime.date(2026, 5, 1),
        )
        InventoryDetail.objects.filter(pk=expiry_detail.pk).update(
            production_date=None,
            expiry_date=None,
        )
        InventoryTransaction.objects.filter(pk=expiry_tx.pk).update(
            production_date=datetime.date(2026, 4, 10),
            expiry_date=datetime.date(2026, 4, 9),
        )

        serial_detail = InventoryDetail.objects.create(
            owner=self.owner,
            product=serial_product,
            warehouse=self.warehouse,
            location=self.location,
            serial_no="SN-001",
            onhand_qty=Decimal("1.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            base_unit=self.base_uom.code,
        )
        serial_tx = self.create_posted_transaction(
            product=serial_product,
            qty_delta="1.0000",
            serial_no="SN-001",
        )
        InventoryDetail.objects.filter(pk=serial_detail.pk).update(
            serial_no="",
            serial_no_norm=None,
        )
        InventoryTransaction.objects.filter(pk=serial_tx.pk).update(
            serial_no="",
            qty_delta=Decimal("2.0000"),
        )

        out = StringIO()
        call_command(
            "reconcile_data_accuracy",
            "--owner",
            str(self.owner.id),
            "--warehouse",
            str(self.warehouse.id),
            "--inventory-only",
            "--json",
            stdout=out,
        )

        payload = json.loads(out.getvalue())
        checks = {check["name"]: check for check in payload["inventory"]["checks"]}
        self.assertFalse(payload["ok"])
        self.assertFalse(checks["inventory_batch_tracking_integrity"]["ok"])
        self.assertFalse(checks["inventory_expiry_tracking_integrity"]["ok"])
        self.assertFalse(checks["inventory_serial_tracking_integrity"]["ok"])
        self.assertIn(
            "missing_batch_no",
            checks["inventory_batch_tracking_integrity"]["samples"][0]["problems"],
        )
        self.assertIn(
            "missing_expiry_date",
            checks["inventory_expiry_tracking_integrity"]["samples"][0]["problems"],
        )
        serial_problem_text = ",".join(
            sample["problems"]
            for sample in checks["inventory_serial_tracking_integrity"]["samples"]
        )
        self.assertIn("missing_serial_no", serial_problem_text)
        self.assertIn("tx_abs_qty_not_one", serial_problem_text)

    def test_reconcile_data_accuracy_cleanup_command_applies_safe_fixes(self):
        self.create_consistent_inventory()
        self.create_consistent_billing()
        InventorySummary.objects.filter(
            owner=self.owner,
            product=self.product,
        ).update(
            onhand_qty=Decimal("4.0000"),
            allocated_qty=Decimal("0.0000"),
            locked_qty=Decimal("0.0000"),
            damaged_qty=Decimal("0.0000"),
            available_qty=Decimal("4.0000"),
        )
        Bill.objects.filter(invoice_no="INV-ACC-001").update(total=Decimal("9.99"))

        out = StringIO()
        call_command(
            "reconcile_data_accuracy_cleanup",
            "--owner",
            str(self.owner.id),
            "--apply-safe-fixes",
            "--json",
            stdout=out,
        )

        payload = json.loads(out.getvalue())
        self.assertFalse(payload["before"]["ok"])
        self.assertEqual(payload["before"]["issue_count"], 2)
        self.assertTrue(payload["after"]["ok"])
        self.assertEqual(payload["after"]["issue_count"], 0)
        self.assertEqual(
            payload["fixes"]["inventory_summaries"]["updated"],
            1,
        )
        self.assertEqual(payload["fixes"]["bill_headers"]["updated"], 1)

        summary = InventorySummary.objects.get(owner=self.owner, product=self.product)
        bill = Bill.objects.get(invoice_no="INV-ACC-001")
        self.assertEqual(summary.onhand_qty, Decimal("5.0000"))
        self.assertEqual(summary.available_qty, Decimal("4.0000"))
        self.assertEqual(bill.total, Decimal("2.50"))

    def test_reconcile_data_accuracy_cleanup_command_skips_summary_rebuild_for_warehouse_scope(
        self,
    ):
        self.create_consistent_inventory()

        out = StringIO()
        call_command(
            "reconcile_data_accuracy_cleanup",
            "--owner",
            str(self.owner.id),
            "--warehouse",
            str(self.warehouse.id),
            "--apply-safe-fixes",
            "--json",
            stdout=out,
        )

        payload = json.loads(out.getvalue())
        self.assertTrue(payload["after"]["ok"])
        self.assertTrue(payload["fixes"]["inventory_summaries"]["skipped"])

    def test_generate_data_accuracy_workpack_command_creates_prefilled_files(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "accuracy-workpack"
            out = StringIO()

            call_command(
                "generate_data_accuracy_workpack",
                "--owner",
                str(self.owner.id),
                "--warehouse",
                str(self.warehouse.id),
                "--period",
                str(self.period.id),
                "--days",
                "5",
                "--output-dir",
                str(output_dir),
                stdout=out,
            )

            self.assertIn(str(output_dir), out.getvalue())
            scope_payload = json.loads((output_dir / "scope.json").read_text(encoding="utf-8"))
            self.assertEqual(scope_payload["owner"]["id"], self.owner.id)
            self.assertEqual(scope_payload["warehouse"]["id"], self.warehouse.id)
            self.assertEqual(scope_payload["period"]["id"], self.period.id)
            self.assertEqual(scope_payload["service_date"], self.period.end_date.isoformat())
            self.assertEqual(scope_payload["shadow_run_days"], 5)

            commands = (output_dir / "commands.sh").read_text(encoding="utf-8")
            self.assertIn(
                (
                    "python manage.py inventory_generate_snapshot "
                    f"--date {self.period.end_date.isoformat()} "
                    f"--owner {self.owner.id} --warehouse {self.warehouse.id}"
                ),
                commands,
            )
            self.assertIn(
                (
                    f"python manage.py reconcile_data_accuracy --owner {self.owner.id} "
                    f"--warehouse {self.warehouse.id} --period {self.period.id} --json"
                ),
                commands,
            )

            runbook = (output_dir / "RUNBOOK.md").read_text(encoding="utf-8")
            self.assertIn(self.owner.code, runbook)
            self.assertIn(self.warehouse.code, runbook)
            self.assertIn(self.period.label, runbook)

            daily_record_rows = (
                (output_dir / "daily-record.csv").read_text(encoding="utf-8").strip().splitlines()
            )
            self.assertEqual(len(daily_record_rows), 10)
            self.assertIn(
                f",{self.owner.id},{self.warehouse.id},{self.period.id},",
                daily_record_rows[1],
            )
            self.assertTrue(daily_record_rows[1].endswith("Day 0 baseline"))
            self.assertTrue(daily_record_rows[-1].endswith("Day 8 shadow run 5/5"))

    def test_generate_data_accuracy_workpack_command_rejects_period_scope_mismatch(
        self,
    ):
        other_warehouse = Warehouse.objects.create(code="ACC-WH-02", name="Other Warehouse")

        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(CommandError):
                call_command(
                    "generate_data_accuracy_workpack",
                    "--owner",
                    str(self.owner.id),
                    "--warehouse",
                    str(other_warehouse.id),
                    "--period",
                    str(self.period.id),
                    "--output-dir",
                    str(Path(tmpdir) / "invalid-workpack"),
                )
