# ===============================
# FILE: allapp/console/urls.py
# 说明：控制台首页（仪表盘）及 API；并挂载 tasking 的 console
# ===============================
from django.urls import path, include
from .views_dashboard import DashboardHomeView, DashboardSummaryApi
from .views_billing import BillingBillDetailView, BillingOverviewView
from .views_salemini import SaleMiniProductListingView

app_name = "console"

urlpatterns = [
    # 首页仪表盘
    path("", DashboardHomeView.as_view(), name="dashboard_home"),
    path("dashboard/", DashboardHomeView.as_view(), name="dashboard_home_alias"),

    # 仪表盘数据（一个端点返回全部图表需要的数据）
    path("api/dashboard/summary/", DashboardSummaryApi.as_view(), name="dashboard_summary"),

    # 计费总览
    path("billing/", BillingOverviewView.as_view(), name="billing_overview"),
    path("billing/overview/", BillingOverviewView.as_view(), name="billing_overview_alias"),
    path("billing/bills/<int:pk>/", BillingBillDetailView.as_view(), name="billing_bill_detail"),

    # 商城运营
    path(
        "sale-mini/products/",
        SaleMiniProductListingView.as_view(),
        name="sale_mini_product_listing",
    ),

    # 若你已在其它地方挂了 tasking console，可以保留一份直达
    path("tasking/", include("allapp.tasking.urls_console", namespace="tasking_console")),
    path("op/", include("allapp.console.urls_op")),
]
