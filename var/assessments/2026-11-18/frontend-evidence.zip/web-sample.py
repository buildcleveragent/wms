from django.conf import settings
from pathlib import Path
root=Path('/wms')
settings.configure(SECRET_KEY='isolated-local-fixture',INSTALLED_APPS=[],DEBUG=True,STATIC_URL='/static/',USE_I18N=False,ROOT_URLCONF=__name__,TEMPLATES=[{'BACKEND':'django.template.backends.django.DjangoTemplates','DIRS':[root/'templates']}])
import django
django.setup()
from django.urls import include,path
from django.template.loader import render_to_string
urlpatterns=[path('console/',include(([path('dashboard-summary/',lambda r:None,name='dashboard_summary')],'console')))]
menu={'active_index':0,'tabs':[{'label':'概览','groups':[{'actions':[{'label':'首页','url':'/'}]}]},{'label':'库存','groups':[{'actions':[{'label':'查询库存','url':'/inventory/'}]}]}]}
target=Path(__file__).with_name('dashboard.html')
target.write_text(render_to_string('console/home.html',{'CONSOLE_MENU':menu,'request':{'user':{'username':'隔离样本'}}}))
