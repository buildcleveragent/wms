const {chromium,expect}=require('/wms/wmspda/node_modules/@playwright/test');const fs=require('node:fs'); const path=require('node:path');
const assert=require('node:assert/strict'); const app=process.argv[2];
const assetDir='/wms/'+app+'/dist/build/h5';const origin='http://127.0.0.1:18123';
const row={id:101,owner_id:8,owner_name:'样本货主',code:'WMS-FIXTURE',sku:'WMS-FIXTURE',name:'仓评样品',price:'5.00',available_qty:'0',base_unit:{id:1,code:'EA',name:'件'},unit_options:[]};
const set={count:0,results:[],next:null,previous:null};
(async()=>{
 const browser=await chromium.launch();
 try{
 const viewport={width:390,height:844}; const page=await browser.newPage({viewport});page.setDefaultTimeout(25000);
 const requests=[],external=[],errors=[]; const report={app,viewport,requests,external,errors};
 page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 if(app!=='sales-miniapp')await page.addInitScript(()=>localStorage.setItem('access','isolated-render-fixture'));
 await page.route('**/*',async r=>{
  const u=new URL(r.request().url());
  if(u.pathname.includes('/api/')){
   const res=(json)=>r.fulfill({json,headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS'}});
   if(u.pathname==='/api/pos/products/'){if(u.searchParams.has('barcode'))return res(set);const zone=u.searchParams.get('zone_type');requests.push({path:u.pathname,search:u.searchParams.get('search'),zone});return res({...set,count:1,results:[{...row,available_qty:zone==='1'?'4.000':'10.000'}]});}
   if(u.pathname==='/api/auth/profile/')return res({user:{id:17,username:'fixture',warehouse_id:3,scopes:{warehouse_ids:[3]}},perms:['pos.add_possale','pos.view_possale','pos.change_possale'],capabilities:{}});
   if(u.pathname==='/api/pos/shifts/current/')return res({shift:{id:6,shift_no:'fixture',status:'OPEN',summary:{}}});
   if(u.pathname.includes('/api/sale-mini/')){requests.push({path:u.pathname,tag:u.searchParams.get('tag')});return res(u.pathname.endsWith('/home/')?{banners:[],categories:[]}:set)}
   return res(set);
  }
  if(u.origin!==origin){external.push(u.hostname+u.pathname);return r.abort('internetdisconnected')}
  const p=path.join(assetDir,u.pathname==='/'?'index.html':decodeURIComponent(u.pathname));
  if(!p.startsWith(assetDir+'/')||!fs.existsSync(p))return r.fulfill({status:404,body:''});
  return r.fulfill({path:p,contentType:({'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.ttf':'font/ttf'})[path.extname(p)]||'application/octet-stream'});
 });
 try{
 if(app==='sales-miniapp'){
  await page.goto(origin+'/#/pages/index/index',{waitUntil:'domcontentloaded'});const tabs=page.locator('.feed-tab');
  await expect(tabs.first()).toBeVisible({timeout:30000});const text=await tabs.nth(1).innerText();await tabs.nth(1).click();await expect(tabs.nth(1)).toHaveClass(/active/);await expect(page.getByText('暂无'+text+'商品',{exact:true})).toBeVisible();report.selected=text;report.active=await page.locator('.feed-tab.active').innerText();
 }else{
  await page.goto(origin+'/#/pages/pos/index',{waitUntil:'domcontentloaded'});
  const input=page.getByTestId('pos-product-input').locator('input');await expect(input).toBeVisible({timeout:30000});await input.fill('仓评样品');await input.press('Enter');
  const result=page.getByTestId('pos-product-row').first();await expect(result).toContainText('仓评样品',{timeout:20000});const text=await result.innerText();report.result=text;
  if(app==='wmspda'){assert(requests.some(x=>x.zone==='1'&&x.search==='仓评样品'));assert(/可售\s*4/.test(text));assert(!/拣货区/.test(text));}
  else{assert(requests.some(x=>!x.zone&&x.search==='仓评样品'));assert(/全仓可用\s*10/.test(text));}
 }
 report.title=await page.title();report.route=await page.evaluate(()=>location.hash);report.overlay=await page.locator('vite-error-overlay').count();report.status='observed';
 }catch(e){report.status='failed';report.error=e.message;report.body=(await page.locator('body').innerText()).slice(0,700);process.exitCode=1;}
 const shot=path.join(__dirname,app+'-sample.png');await page.screenshot({path:shot});report.screenshot=shot;console.log(JSON.stringify(report,null,2));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1})
