import json, os
from types import SimpleNamespace
os.environ.setdefault('DJANGO_SETTINGS_MODULE','wmsmaster.settings')
from django.conf import settings
settings.DATABASES={'default':{'ENGINE':'django.db.backends.dummy'}}
import django
django.setup()
from allapp.console.menu import build_ribbon
from allapp.console.context_processors import console_menu
from django.db.backends.base.base import BaseDatabaseWrapper
def deny_connection(*args,**kwargs): raise AssertionError('Database connection forbidden in menu fixture')
BaseDatabaseWrapper.ensure_connection=deny_connection
for name,superuser,permissions in [('零业务权限',False,set()),('仓库库存查看',False,{'inventory.view_inventorydetail','tasking.view_wmstask'}),('全权限参照',True,set())]:
 user=SimpleNamespace(is_authenticated=True,is_superuser=superuser,has_perm=lambda perm:perm in permissions,groups=SimpleNamespace(all=lambda:[]))
 request=SimpleNamespace(user=user,path='/')
 menu=console_menu(request)['CONSOLE_MENU']; items=[a['label'] for t in menu['tabs'] for g in t['groups'] for a in g['actions']]
 print(json.dumps({'sample':name,'tabs':[t['label'] for t in menu['tabs']],'count':len(items),'examples':items[:9]},ensure_ascii=False))
 assert len(items)>0
