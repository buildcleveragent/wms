const {chromium}=require('/wms/wmspda/node_modules/playwright');
const fs=require('node:fs'); const path=require('node:path'); const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch();
 try{
 const results=[];
 for(const viewport of [{width:1440,height:900},{width:390,height:844}]){
  let blocked=0,api=0;const errors=[];const page=await browser.newPage({viewport});
  page.on('pageerror',e=>errors.push(e.message));
  page.on('console',e=>{if(e.type()==='error')errors.push(e.text())});
  await page.route('**/*',r=>{
   const u=new URL(r.request().url());
   if(u.hostname==='cdn.jsdelivr.net'){blocked++;return r.abort('internetdisconnected')}
   if(u.hostname!=='wms-ui.invalid')return r.abort();
   if(u.pathname==='/')return r.fulfill({contentType:'text/html;charset=utf-8',body:fs.readFileSync(path.join(__dirname,'dashboard.html'))});
   if(u.pathname==='/console/dashboard-summary/'){api++;return r.fulfill({json:{ok:true,data:{kpi:{putaway:{total:8,done:6},pick:{total:5,done:1}},no_order_receive:{available:true,summary:{qty:'8.000'}},pos:{available:true,today:{summary:{net_amount:'21.00'}}}}}})}
   if(u.pathname==='/static/img/aaa.png')return r.fulfill({path:'/wms/static/img/aaa.png'});
   return r.fulfill({status:204});
  });
  await page.goto('https://wms-ui.invalid/',{waitUntil:'networkidle'});
  const title=await page.title();assert.equal(title,'仓库运营看板');
  await page.getByRole('tab',{name:'概览'}).click();
  await page.keyboard.press('ArrowRight');
  assert.equal(await page.getByRole('tab',{name:'库存'}).getAttribute('aria-selected'),'true');
  const actionVisible=await page.getByRole('link',{name:'查询库存'}).isVisible();assert.equal(actionVisible,viewport.width>768);
  const kpi=await page.locator('#k_put_rate').innerText();
  assert.equal(kpi,'完成率 75%');
  const chartFailures=await page.locator('.chart-failed:visible').count();
  assert.equal(chartFailures,10);assert.equal(api,1);assert.equal(blocked,1);
  const warning=await page.locator('#dashboard-warning').innerText();
  assert(warning.includes('图表组件加载失败'));const overlay=await page.locator('vite-error-overlay').count();
  const image=path.join(__dirname,'web-dashboard-'+viewport.width+'.png');await page.screenshot({path:image});
  results.push({viewport,title,kpi,blocked,api,chartFailures,warning,overlay,errors,actionVisible,roleTab:'库存',screenshot:image});await page.close();
 }
 console.log(JSON.stringify(results,null,2));
 }finally{await browser.close()}
})().catch(e=>{console.error(e.message);process.exit(1)})
