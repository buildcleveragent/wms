const {chromium,expect}=require('/wms/wmspda/node_modules/@playwright/test');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const app=process.argv[2], origin='http://127.0.0.1:18287',dir='/wms/'+app+'/dist/build/h5';
const price=JSON.parse(fs.readFileSync(__dirname+'/price-verdict.json'))[0];
const item={id:1,owner_id:8,owner_name:'样本货主',code:'SYNTHETIC-WEIGHT',sku:'SYNTHETIC-WEIGHT',name:'称重样品',price:'1.23',available_qty:'10.000',base_unit:{id:1,code:'KG',name:'千克'},unit_options:[{kind:'base',label:'千克',multiplier:'1'}]};
const sale={id:41,sale_no:'SIM-S41',status:'COMPLETED',total_amount:'18.00',payment:{method:'CASH'},lines:[{id:82,product_name:'测试件',base_unit:'件',qty:'2.000',price:'9.0000',amount:'18.00',returnable_qty:'2.000'}]};
(async()=>{
const start=Date.now(),browser=await chromium.launch();const page=await browser.newPage({viewport:{width:390,height:844},serviceWorkers:'block'});page.setDefaultTimeout(20000);
const errors=[],unexpected=[],queries=[],checkouts=[],returns=[];const info={app,errors,unexpected,queries,checkouts,returns};
page.on('pageerror',e=>errors.push(e.message));page.on('console',e=>{if(e.type()==='error'&&!/Failed to load resource/.test(e.text()))errors.push(e.text())});
await page.addInitScript(()=>localStorage.setItem('access','isolated-render-fixture'));
let mallError=false;
await page.route('**/*',async r=>{
 const u=new URL(r.request().url()),p=u.pathname;
 if(p.includes('/api/')){
 const send=(json,status=200)=>r.fulfill({status,json,headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS'}});
 if(r.request().method()==='OPTIONS')return send({});
 if(p==='/api/auth/profile/')return send({user:{id:7,username:'fixture',warehouse_id:3,scopes:{warehouse_ids:[3]}},perms:['pos.add_possale','pos.view_possale','pos.change_possale','pos.add_posreturn','pos.add_posrefund'],capabilities:{}});
 if(p==='/api/pos/shifts/current/')return send({shift:{id:6,shift_no:'合成班次',opened_at:'2026-11-18T08:00:00Z',cashier_id:7,warehouse_id:3,status:'OPEN',summary:{}}});
 if(p==='/api/pos/products/'){queries.push({zone:u.searchParams.get('zone_type'),search:u.searchParams.get('search')});return send({count:1,results:u.searchParams.has('barcode')?[]:[item]})}
 if(p==='/api/pos/checkout/'){checkouts.push(r.request().postDataJSON().items);return send({price:['成交单价必须等于总金额除以数量后的四位小数结果 1.2400。']},400)}
 if(p==='/api/pos/sales/')return send({count:1,results:[sale]});
 if(p==='/api/pos/sales/41/')return send(sale);
 if(p==='/api/pos/returns/'&&r.request().method()==='POST'){returns.push(r.request().postDataJSON());return returns.length===1?r.abort():send({return:{id:51,sale_id:41}})}
 if(p.includes('/api/sale-mini/')){queries.push({path:p,tag:u.searchParams.get('tag')});return mallError&&u.searchParams.has('tag')?send({detail:'样本：商品服务暂不可用'},503):send(p.endsWith('/home/')?{categories:[],banners:[]}:{count:0,results:[]})}
 return send({count:0,results:[]});}
 if(u.origin!==origin){unexpected.push(u.hostname+u.pathname);return r.abort()}
 const f=path.join(dir,p==='/'?'index.html':p);if(!f.startsWith(dir+'/')||!fs.existsSync(f))return r.fulfill({status:404});
 return r.fulfill({path:f,contentType:({'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.ttf':'font/ttf'})[path.extname(f)]||'application/octet-stream'});
});
try{
 if(app==='sales-miniapp'){
 await page.goto(origin+'/#/pages/index/index');const tabs=page.locator('.feed-tab');await tabs.nth(1).click();await expect(tabs.nth(1)).toHaveClass(/active/);await expect(page.getByText('暂无新品商品')).toBeVisible();info.ordinaryEmpty=await page.getByText('暂无新品商品').innerText();mallError=true;await tabs.nth(2).click();await expect.poll(()=>queries.filter(x=>x.tag==='recommended').length).toBeGreaterThan(0);await expect(page.getByText('暂无推荐商品')).toBeVisible();await page.waitForTimeout(3000);info.after503=(await page.locator('body').innerText()).trim();info.visibleRetryTexts=await page.getByText(/重试|重新加载/).filter({visible:true}).allInnerTexts();await page.screenshot({path:__dirname+'/mall-error.png'});
 }else{
 await page.goto(origin+'/#/pages/pos/index');const input=page.getByTestId('pos-product-input').locator('input');
 await input.fill(item.name);await input.press('Enter');const result=page.getByTestId('pos-product-row').first();await expect(result).toContainText(/拣货区＋存储区可售\s*10\s*千克/);info.stock=await result.innerText();await result.getByText('加入',{exact:true}).click();
 if(await page.getByText('自动打印销售单',{exact:true}).count())await page.getByText('自动打印销售单',{exact:true}).click();
 const qty=page.locator('.cart-row .small-input input').first();await qty.fill('0.5');await qty.blur();
 await page.getByTestId('pos-checkout').click();await expect.poll(()=>checkouts.length).toBe(1);
 info.fractionalMatchesBackendProbe=JSON.stringify(checkouts[0][0])===JSON.stringify(price.line);assert.deepEqual(checkouts[0][0],price.line);
 await expect(page.locator('.uni-modal__btn_primary')).toBeVisible();await page.screenshot({path:__dirname+'/pda-fractional.png'});await page.locator('.uni-modal__btn_primary').click();
 await page.getByText('退货',{exact:true}).first().click();const form=page.getByTestId('pos-return-form');
 await form.locator('.return-qty-input input').fill('1');await form.locator('.return-qty-input input').blur();await form.locator('.void-input input').fill('退一件');await page.getByTestId('pos-return-confirm').click();await page.locator('.uni-modal__btn_primary').click();
 await expect(page.getByTestId('pos-return-pending')).toBeVisible();await page.reload();await expect(page.getByTestId('pos-return-pending')).toContainText('9.00');await page.screenshot({path:__dirname+'/pda-return-pending.png'});await page.getByTestId('pos-return-retry').click();await expect.poll(()=>returns.length).toBe(2);await expect(page.getByTestId('pos-return-pending')).toHaveCount(0);assert.deepEqual(returns[0],returns[1]);info.sameReturn=true;
 }
 info.route=await page.evaluate(()=>location.hash);info.title=await page.title();info.overlay=await page.locator('vite-error-overlay').count();info.status='observed'
}catch(e){info.error=e.message;info.body=(await page.locator('body').innerText()).slice(-1800);info.status='failed';process.exitCode=1}
info.seconds=(Date.now()-start)/1000;fs.writeFileSync(__dirname+'/'+app+'-probe.json',JSON.stringify(info,null,2));await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1})
