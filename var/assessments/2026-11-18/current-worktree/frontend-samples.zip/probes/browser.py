import os,time,json,subprocess,sys
from pathlib import Path
tmp=Path('/tmp/wms-fe-audit-v3')
repo=Path('/wms')
jobs={
'pda':('wmspda', 'tests/e2e', 5173,['pos-stock-zones.spec.js','product-search-keyboard-scanner.spec.js','home-todos.spec.js']),
'android':('wmsandroid','tests/e2e',18119,['mobile-recovery.spec.js','mobile-pos.spec.js','-g','return recovery preserves|zero-priced goods|default saleable zones|checkout keeps one request']),
'owner':('wmsownersale','e2e',5177,['inventory.spec.js']),
'boss':('wmsbossbilling','e2e',5176,['entry-and-recovery.spec.js','-g','authenticated cold start|transient detail failure|manual retry']),
}
for key in sys.argv[1:]:
 app,tests,port,args=jobs[key]
 for _ in range(200):
  if (tmp/(app+'-builds.json')).exists():break
  time.sleep(3)
 else: raise SystemExit('build log missing')
 if json.loads((tmp/(app+'-builds.json')).read_text())['rc']:continue
 start=time.monotonic()
 config=tmp/(key+'.config.cjs')
 output=tmp/(key+'-browser')
 project='android-390' if key=='android' else 'chromium'
 config.write_text('module.exports='+json.dumps({
 'testDir':str(repo/app/tests),'timeout':100000,'workers':1,'retries':0,'reporter':[['list'],['json',{'outputFile':str(tmp/(key+'-browser.json'))}]],'outputDir':str(output),'expect':{'timeout':15000},
 'projects':[{'name':project,'use':{'browserName':'chromium','viewport':{'width':390 if key=='android' else 1280,'height':844},'isMobile':key=='android','hasTouch':key=='android'}}],
 'use':{'baseURL':'http://127.0.0.1:'+str(port),'navigationTimeout':45000,'screenshot':'only-on-failure','trace':'off'},
 'webServer':{'command':'python3 -m http.server '+str(port)+' --bind 127.0.0.1 --directory '+str(repo/app/'dist/build/h5'),'url':'http://127.0.0.1:'+str(port),'reuseExistingServer':False,'timeout':45000}
 }))
 with (tmp/(key+'-browser.log')).open('w') as log:
  cmd=[str(repo/app/'node_modules/.bin/playwright'),'test','--config',str(config)]+args
  run=subprocess.run(cmd,cwd=repo/app,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CI='1',PDA_E2E_BUILT='1',BOSS_E2E_BUILT='1',NO_COLOR='1',FORCE_COLOR='0'))
 (tmp/(key+'-browser-meta.json')).write_text(json.dumps({'command':cmd,'rc':run.returncode,'seconds':round(time.monotonic()-start,2)}))
