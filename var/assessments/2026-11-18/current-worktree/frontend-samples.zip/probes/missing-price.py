import json, os
from decimal import Decimal
from types import SimpleNamespace
from pathlib import Path
from subprocess import run
os.environ.setdefault('DJANGO_SETTINGS_MODULE','wmsmaster.settings')
from django.conf import settings
settings.DATABASES={'default':{'ENGINE':'django.db.backends.dummy'}}
from django.db.backends.base.base import BaseDatabaseWrapper
def forbid(*args,**kwargs): raise AssertionError('unexpected database access')
BaseDatabaseWrapper.ensure_connection=forbid
import django
django.setup()
from allapp.pos.serializers import PosProductSerializer, PosCheckoutLineSerializer
from allapp.pos.services import _validate_prices_and_shape
base=Path(__file__).parent
meta=SimpleNamespace(id=3,code='NO-PRICE',price=None,min_price=None,max_discount=None)
unit=PosProductSerializer().get_price(meta)
script="""const p = require(process.argv[1]);const raw={id:3,code:'NO-PRICE',name:'未定价样品',owner_id:1,base_unit:{name:'件'},price:process.argv[2],available_qty:'1'};const item=p.createCartItem(raw);console.log(JSON.stringify({validation:p.validateCart([item]),payload:p.buildCheckoutSnapshot({items:[item],paymentMethod:'WECHAT',amountReceived:0}).payload}));"""
client=json.loads(run(['node','-e',script,str(base/'pos.bundle.cjs'),str(unit)],capture_output=True,check=True,text=True).stdout)
serializer=PosCheckoutLineSerializer(data=client['payload']['items'][0])
serializer.is_valid(raise_exception=True)
normalized,_=_validate_prices_and_shape([serializer.validated_data],{3:meta})
print(json.dumps({'catalog_price':None,'catalog_serializer':str(unit),'android_cart_validation':client['validation'],'android_line':client['payload']['items'][0],'accepted_server_line_amount':str(normalized[0]['amount']),'android_payment':client['payload']['payment']},ensure_ascii=False,indent=2))
