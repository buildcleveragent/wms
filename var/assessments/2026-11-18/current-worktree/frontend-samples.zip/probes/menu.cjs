const {chromium,expect}=require('/wms/wmspda/node_modules/@playwright/test'),fs=require('node:fs'),assert=require('node:assert/strict');
const src=fs.readFileSync('/wms/scripts/console-dashboard-browser.mjs','utf8');
const data=Function(src.slice(src.indexOf('const dates ='),src.indexOf('await mkdir(artifacts'))+'return summary(false)')();
const origin='https://dashboard.invalid',root=__dirname;
(async()=>{const browser=await chromium.launch(),result=[];
for(const width of [390,1440]){
const row={width,external:[],errors:[],warnings:[],charts:null};const page=await browser.newPage({viewport:{width,height:844},serviceWorkers:'block'});page.setDefaultTimeout(30000);
page.on('pageerror',e=>row.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')row.errors.push(m.text());if(m.type()==='warning')row.warnings.push(m.text())});
await page.route('**/*',async r=>{const u=new URL(r.request().url());
if(u.origin!==origin){row.external.push(u.hostname);return r.abort()}
if(u.pathname==='/')return r.fulfill({contentType:'text/html;charset=utf-8',body:fs.readFileSync(root+'/dashboard.html')});
if(u.pathname==='/console/dashboard-summary/')return r.fulfill({json:data});
if(u.pathname.startsWith('/static/'))return r.fulfill({path:'/wms'+u.pathname,contentType:u.pathname.endsWith('js')?'application/javascript':'image/png'});
return r.fulfill({status:404})});
try{
await page.goto(origin,{waitUntil:'load',timeout:60000});await expect(page).toHaveTitle('仓库运营看板');await expect(page.locator('#k_put_rate')).toHaveText('完成率 75%',{timeout:30000});
await expect(page.locator('.chart canvas')).toHaveCount(10,{timeout:30000});row.charts=await page.locator('.chart canvas').count();row.kpi=await page.locator('#k_put_rate').innerText();
await page.getByRole('tab',{name:'概览'}).click();await page.keyboard.press('ArrowRight');await expect(page.getByRole('tab',{name:'库存'})).toHaveAttribute('aria-selected','true');const link=page.getByRole('link',{name:'查询库存'});await expect(link).toBeVisible();row.menu=await link.boundingBox();row.bodyWidth=await page.evaluate(()=>document.documentElement.scrollWidth);row.overlay=await page.locator('vite-error-overlay').count();row.title=await page.title();row.url=page.url();await page.screenshot({path:root+'/menu-chart-'+width+'.png'});assert.equal(row.external.length,0);
}catch(e){row.failure=e.message;row.messages=await page.locator('#dashboard-warning,#dashboard-error').allInnerTexts();row.library=await page.evaluate(()=>typeof window.echarts);row.charts=await page.locator('.chart canvas').count();process.exitCode=1}await page.close();result.push(row)}
await browser.close();fs.writeFileSync(root+'/menu-chart.json',JSON.stringify(result,null,2))
})().catch(e=>{console.error(e);process.exitCode=1});
