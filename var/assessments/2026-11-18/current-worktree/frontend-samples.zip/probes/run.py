from pathlib import Path
import os, time, subprocess, sys, json
from concurrent.futures import ThreadPoolExecutor
root=Path('/wms')
out=Path('/tmp/wms-fe-audit-v3')
jobs={
 'units':[(a,['npm','run','test:unit','--','--maxWorkers=1']) for a in ['wmspda','wmsandroid','wmsownersale','wmsbossbilling']]+[('sales-miniapp',['node','--test']+[str(p.relative_to(root/'sales-miniapp')) for p in sorted((root/'sales-miniapp/tests').glob('*.test.mjs'))])],
 'builds':[(a,['npm','run','build:h5']) for a in ['wmspda','wmsandroid','wmsownersale','wmsbossbilling','sales-miniapp']],
 'contracts':[('wmsownersale',['npm','run','test:contracts']),('sales-miniapp',['npm','run','test:structure'])],
}
kind=sys.argv[1]
def run(job):
 a,cmd=job
 key=a+'-'+kind
 env=dict(os.environ,CI='1',NO_COLOR='1',FORCE_COLOR='0')
 if kind=='builds' and a=='wmsandroid':env['VITE_API_BASE_URL']='http://127.0.0.1:8001'
 start=time.monotonic()
 with (out/(key+'.log')).open('w') as log:
  proc=subprocess.run(cmd,cwd=root/a,env=env,stdout=log,stderr=subprocess.STDOUT)
 result={'app':a,'command':cmd,'seconds':round(time.monotonic()-start,2),'rc':proc.returncode}
 (out/(key+'.json')).write_text(json.dumps(result))
 print(result,flush=True)
with ThreadPoolExecutor(max_workers=2 if kind=='units' else 1) as pool:list(pool.map(run,jobs[kind]))
