const esbuild = require('/wms/wmsandroid/node_modules/esbuild')
const fs = require('node:fs')
const dest='/tmp/wms-fe-audit-v3'
esbuild.buildSync({ entryPoints: ['/wms/wmsandroid/utils/posMobile.js'], bundle: true, format: 'cjs', platform: 'node', alias:{'@':'/wms/wmsandroid'},define:{'import.meta.env':'{}'},outfile:dest+'/pos.bundle.cjs' })
const { createCartItem, validateCart,buildCheckoutSnapshot }=require(dest+'/pos.bundle.cjs')
const samples=[]
for (const qty of ['0.500','1.000','2.500']){
 const item=createCartItem({id:1,owner_id:1,code:'SYNTHETIC-WEIGHT',name:'称重样品',price:'1.23',available_qty:'100.000',base_unit:{name:'千克'}})
 item.qty=qty
 const payload=buildCheckoutSnapshot({items:[item],paymentMethod:'CASH',amountReceived:5}).payload
 samples.push({cart_validation:validateCart([item]),line:payload.items[0],received:payload.payment.amount_received})
}
fs.writeFileSync(dest+'/client-price.json',JSON.stringify(samples,null,2))
