const {chromium,expect}=require('/wms/wmspda/node_modules/@playwright/test');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const app=process.argv[2], origin='http://127.0.0.1:18287',dir='/wms/'+app+'/dist/build/h5';
const price=JSON.parse(fs.readFileSync(__dirname+'/price-verdict.json'))[0];
const item={id:1,owner_id:8,owner_name:'样本货主',code:'SYNTHETIC-WEIGHT',sku:'SYNTHETIC-WEIGHT',name:'称重样品',price:'1.23',available_qty:'10.000',base_unit:{id:1,code:'KG',name:'千克'},unit_options:[{kind:'base',label:'千克',multiplier:'1'}]};
const sale={id:41,sale_no:'SIM-S41',status:'COMPLETED',total_amount:'18.00',payment:{method:'CASH'},lines:[{id:82,product_name:'测试件',base_unit:'件',qty:'2.000',price:'9.0000',amount:'18.00',returnable_qty:'2.000'}]};
(async()=>{
const start=Date.now(),browser=await chromium.launch();const page=await browser.newPage({viewport:{width:390,height:844},serviceWorkers:'block'});page.setDefaultTimeout(20000);
const errors=[],unexpected=[],queries=[],checkouts=[],returns=[];const info={app,errors,unexpected,queries,checkouts,returns};
page.on('pageerror',e=>errors.push(e.message));page.on('console',e=>{if(e.type()==='error'&&!/Failed to load resource/.test(e.text()))errors.push(e.text())});
await page.addInitScript(()=>localStorage.setItem('access','isolated-render-fixture'));
let mallError=false;
await page.route('**/*',async r=>{
 const u=new URL(r.request().url()),p=u.pathname;
 if(p.includes('/api/')){
 const send=(json,status=200)=>r.fulfill({status,json,headers:{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS'}});
 if(r.request().method()==='OPTIONS')return send({});
 if(p==='/api/auth/profile/')return send({user:{id:7,username:'fixture',warehouse_id:3,scopes:{warehouse_ids:[3]}},perms:['pos.add_possale','pos.view_possale','pos.change_possale','pos.add_posreturn','pos.add_posrefund'],capabilities:{}});
 if(p==='/api/pos/shifts/current/')return send({shift:{id:6,shift_no:'合成班次',opened_at:'2026-11-18T08:00:00Z',cashier_id:7,warehouse_id:3,status:'OPEN',summary:{}}});
 if(p==='/api/pos/products/'){queries.push({zone:u.searchParams.get('zone_type'),search:u.searchParams.get('search')});return send({count:1,results:u.searchParams.has('barcode')?[]:[item]})}
 if(p==='/api/pos/checkout/'){checkouts.push(r.request().postDataJSON().items);return send({price:['成交单价必须等于总金额除以数量后的四位小数结果 1.2400。']},400)}
 if(p==='/api/pos/sales/')return send({count:1,results:[sale]});
 if(p==='/api/pos/sales/41/')return send(sale);
 if(p==='/api/pos/returns/'&&r.request().method()==='POST'){returns.push(r.request().postDataJSON());return returns.length===1?r.abort():send({return:{id:51,sale_id:41}})}
 if(p.includes('/api/sale-mini/')){queries.push({path:p,tag:u.searchParams.get('tag')});return mallError&&u.searchParams.has('tag')?send({detail:'样本：商品服务暂不可用'},503):send(p.endsWith('/home/')?{categories:[],banners:[]}:{count:0,results:[]})}
 return send({count:0,results:[]});}
 if(u.origin!==origin){unexpected.push(u.hostname);return r.abort()}
 const f=path.join(dir,p==='/'?'index.html':p);if(!f.startsWith(dir+'/')||!fs.existsSync(f))return r.fulfill({status:404});
 return r.fulfill({path:f,contentType:({'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.ttf':'font/ttf'})[path.extname(f)]||'application/octet-stream'});
});

try{
info.geometry=[];
for(const width of [390,768,1280]){
 await page.setViewportSize({width,height:844});
 await page.goto(origin+'/#/pages/pos/index');await expect(page.getByText('合成班次')).toBeVisible({timeout:45000});
 const metric=await page.locator('.shift-numbers').evaluate(el=>{
  const normalize=r=>({x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)});
  const control=document.querySelector('.shift-cash-input').getBoundingClientRect();
  const cross=(a,b)=>Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left))*Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
  const metrics=[...el.children].map(e=>{const r=document.createRange();r.selectNodeContents(e); const rects=[...r.getClientRects()];return {text:e.innerText,box:normalize(e.getBoundingClientRect()),cashInputOverlapped:rects.some(a=>cross(a,control)>0),textLines:rects.length}});
  return {box:normalize(el.getBoundingClientRect()),cashInput:normalize(control),metrics,cardHeight:document.querySelector('.shift-card').getBoundingClientRect().height};
 });info.geometry.push({width,...metric});await page.locator('.shift-section').screenshot({path:__dirname+'/shift-'+width+'.png'});
}info.status='observed';
}catch(e){info.error=e.message;info.status='failed';process.exitCode=1}
info.seconds=(Date.now()-start)/1000;fs.writeFileSync(__dirname+'/layout.json',JSON.stringify(info,null,2));await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1})
