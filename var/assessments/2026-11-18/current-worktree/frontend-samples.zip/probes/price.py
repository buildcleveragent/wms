import json,os
from pathlib import Path
from types import SimpleNamespace
os.environ.setdefault('DJANGO_SETTINGS_MODULE','wmsmaster.settings')
from django.conf import settings
settings.DATABASES={'default':{'ENGINE':'django.db.backends.dummy'}}
from django.db.backends.base.base import BaseDatabaseWrapper
def forbid(*args,**kwargs): raise AssertionError('unexpected Database access')
BaseDatabaseWrapper.ensure_connection=forbid
import django
django.setup()
from allapp.pos.services import _validate_prices_and_shape
from allapp.pos.serializers import PosCheckoutLineSerializer
from django.core.exceptions import ValidationError
from decimal import Decimal
root=Path(__file__).parent
samples=json.loads((root/'client-price.json').read_text())
product=SimpleNamespace(id=1,code='SYNTHETIC-WEIGHT',price=Decimal('1.23'),min_price=None,max_discount=None)
for row in samples:
 entry=PosCheckoutLineSerializer(data=row['line'])
 assert entry.is_valid(),entry.errors
 try:
  normalized,quantities=_validate_prices_and_shape([entry.validated_data],{1:product})
 except ValidationError as exc:
  row['result']='rejected'
  row['error']=str(exc)
 else:
  row['result']='accepted'
  row['amount']=str(normalized[0]['amount'])
print(json.dumps(samples,ensure_ascii=False,indent=2))
