# 重新验证多端样本

解包 probes 到 /tmp/wms-fe-audit-v3。在同一工作树 /wms 使用仓库已安装的 Node、Playwright、Chromium 和 .venv。保留合成数据；价格脚本在 Django 初始化前切换 dummy 数据库并禁止数据库连接。运行下列命令会写入该临时目录和应用的忽略构建目录。

1. python3 /tmp/wms-fe-audit-v3/run.py units，builds 和 contracts 各执行一次。所有依赖完成后可运行 python3 /tmp/wms-fe-audit-v3/browser.py pda android owner boss 复查仓库的构建浏览器用例。
2. node /tmp/wms-fe-audit-v3/price.cjs 生成 Android 的购物车快照。APP_ENV=test PYTHONPATH=/wms /wms/.venv/bin/python /tmp/wms-fe-audit-v3/price.py > /tmp/wms-fe-audit-v3/price-verdict.json 和相同环境的 missing-price.py 验证真实服务校验及未定价。
3. node /tmp/wms-fe-audit-v3/mobile.cjs wmspda 和 sales-miniapp 依次执行，再运行 node /tmp/wms-fe-audit-v3/layout.cjs wmspda 核实窄屏布局。所有请求都由页面夹具拦截，禁止访问生产服务。
4. /wms/.venv/bin/python /tmp/wms-fe-audit-v3/web-sample.py 再 node /tmp/wms-fe-audit-v3/menu.cjs 检查离线菜单与图表。官方测试另有 APP_ENV=test /wms/.venv/bin/pytest -q scripts/test_console_dashboard_browser.py。

多端样本包括模拟断网、柜台交班及错误反馈；浏览器正常运行不代表原生硬件、支付通道或实际业务入账完成。report.json 为本轮冻结时的摘要。
